# Evidence notes

Captured 2026-10-23 Asia/Shanghai. Baseline main: da8e3b54df99a3e63246c496ade226890bf236ba. Application implementation commit: 576cba391939b60a3eef7a5c7778f7a466edb7ae. The follow-up commit adds this evidence packet and its documentation only.

before/after snapshots cover 26 local webpack-rendered URLs. Metadata, headings and relations are equal throughout; only two English targets differ in body, links and listed local JSON-LD fields. Baseline target/locale captures precede source edits. Two transient unchanged control renders were recaptured after development cache errors.

build.log is the actual repository build: production compilation succeeds, then existing params typing fails. baseline-typecheck.log and typecheck-final.log have the same 16 unique diagnostics, normalizing duplicate .next/dev entries. No new diagnostic was added.

preview-build.log is a DIFFERENT scratch-only build from archived source with the two final source modules overlaid. Only that copy added typescript.ignoreBuildErrors=true and experimental.cpus=2. Its 135-page generation succeeds. This does not establish an unmodified repository build pass. No such config change is in the PR. Production-renderer interaction checks use localhost:3001. Intermediate development-mode download failures are not reported as successes.

Browser external requests were blocked; /api/* was intercepted with local fixtures; R2 image-optimizer requests were blocked for the stable interaction checks. Blank remote assets in screenshots do not diagnose CDN/CORS. No Gallery management, auth, AI, payment or production write was performed. OpenCV is blocked, so full upload-to-generated-PDF remains unverified.

Four local Rabbit/Puppy puzzle PDFs and solution PNGs were downloaded. PDF JPEG pixels match puzzle sources with RMSE below 0.23; PNG pixels exactly match solution sources. Hashes and A4/credit assertions are in downloads/downloads.json. This is not independent sequence/play/print/licensing QA.

The Python scripts are the exact environment harnesses, not a portable test suite. They use installed Playwright, Chromium, Pillow and PyMuPDF and refer to the capture workspace paths. No new puzzle assets were produced. implementation.patch contains the application change and original review documents against the baseline, before this evidence-only commit.
